$.pnotify({
	title: 'Hello World',
	text: 'To edit this message, find me in Kickstrap/apps/pinesnotify/msg.js'
});